# enroll 
# templates//enroll
# 1.html






# myapp
# templates//myapp
# 1.html



# 'enroll/1.html'


# 'myapp/1.html'
#######################################################
# CRUD 
# djang

















